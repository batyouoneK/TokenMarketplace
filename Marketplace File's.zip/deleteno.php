<?php include('includes/init.php'); ?>

<?php

$update = Users::updateno();

redirect('login.php');

?>