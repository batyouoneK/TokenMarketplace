<div class="row">

    <div class="col-md-12">
    
        <h3>To Do List</h3>
        <p>All those settings are very important, be sure you have done them!</p>
    
        <div class="card">
            <div class="card-header">
                <strong class="card-title">**Important</strong>
            </div>
            <div class="card-body">
                <p class="card-text">
                    <strong>- Coinpayments IPN URL:</strong> https://website.com/ipn_handler.php
                </p>
                
                <p class="card-text">
                    <strong>- CoinPayments Accepted Coin:</strong> Only the currency used in AnyCoin Script!
                </p>
                
                <p class="card-text">
                    <strong>- Coinpayments Settings</strong>
                </p>
                
                <p class="card-text">
                    <strong>- SMTP Settings:</strong> SMTP are a must for email feature to work!
                </p>
                
                <p class="card-text">
                    <strong>- Recaptcha Settings</strong>
                </p>
                
                <p class="card-text">
                    <strong>- Cronjob check plans: </strong>https://website.com/cronjob/check-plans.php - <span> 5 minutes</span>
                </p>
                
                <p class="card-text">
                    <strong>- Cronjob check no credited miners: </strong>https://website.com/cronjob/check-nocredited.php - <span> 5 minutes</span>
                </p>
                <p class="card-text">(Recommended for cronjobs: https://www.easycron.com/)</p>
                
            </div>
        </div>
        
    </div>

</div>