        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header text-center">
                    <a class="navbar-brand" href="./">
                    <h5><?php echo $setting->title; ?></h5>
                    </a>
                    <a class="navbar-brand hidden" href="./">AnyCoin Script</a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
                    <div class="header-left">


                    </div>

                </div>
            </div>
        </header>