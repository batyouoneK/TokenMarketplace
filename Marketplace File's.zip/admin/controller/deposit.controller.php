<?php 

$payments = Payment::get_all_deposits();

?>