    <!-- Left Panel -->
    
    <!-- /#left-panel -->