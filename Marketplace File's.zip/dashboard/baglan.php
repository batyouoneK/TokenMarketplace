<?php

$baglan = mysqli_connect("localhost","root","root","anycoin");

if(!$baglan){
    die("connection failed:".mysqli_connect_error());
}
else
{
  
}

?>