    <!-- Hero section -->
	<section class="hero-section">
		<div class="container">
			<div class="row">
				<div class="col-md-6 hero-text">
					<h2>Invest in <span><?php echo $setting->currency ?></span> <br>Cloud Mining</h2>
					<h4><?php echo $setting->home_subtitle ?></h4>
                    <span class="text-warning">THIS DEMO IS USING <strong>DOGECOIN</strong> as main currency!</span>
				</div>
				<div class="col-md-6">
					<img src="assets/img/client-dashboard.png" class="laptop-image" alt="">
				</div>
			</div>
		</div>
	</section>
	<!-- Hero section end -->